
	package books;

	import java.io.BufferedReader;
	import java.io.FileNotFoundException;
	import java.io.FileReader;
	import java.io.IOException;
	import java.util.ArrayList;
	import java.util.Comparator;
	import java.util.List;
	//that's kind of alot of imports but it works.


	/**
	 *
	 * @author Arkzend
	 */
	public class Book2 implements Comparable<Book> {

	    public static final Comparator byAuthor = new AuthorComparator();
	    public static final Comparator byYear = new YearComparator();
	    private String title;
	    private String author;
	    private int year;

	    public Book2(String title, String author, int year) {
	        this.title = title;
	        this.author = author;
	        this.year = year;
	    }

	    public String getTitle() {
	        return this.title;
	    }

	    public String getAuthor() {
	        return this.author;
	    }

	    public int getYear() {
	        return this.year;
	    }

	    @Override
	    public String toString() {
	        return this.title + " by " + this.author
	                + " ( " + this.year + " )";
	    }
	    //pretty standard stuff up to this point
	    
	    public static List<Book> getList(String file)
	    {
	        int booksRead = 0; //counter for number of books read in through the file
	        BufferedReader input; // input reader
	        List<Book> temp = new ArrayList<>(); // set up for the return list
	        try // try here to make sure bufferedreader doesn't fail
	        {
	            input = new BufferedReader(new FileReader(file));
	            String line = input.readLine();
	            do //tried while loop with (input.readLine() != null)but that made it miss lines. so went with a do loop
	                //this now means i'm assuming you're not gonna use a file that has no data at all
	            {
	                try // try here to make sure we don't get any index or format errors on parsing and assignment
	                {
	                    String[] temps = line.split(",");
	                    String tempTitle = temps[0];
	                    String tempAuthor = temps[1];
	                    int tempYear = Integer.parseInt(temps[2]);
	                    temp.add(new Book(tempTitle, tempAuthor, tempYear));
	                    booksRead++;
	                } catch (ArrayIndexOutOfBoundsException | NumberFormatException ex)
	                {
	                System.err.println("Could not read line: " + line); // on my outputs the second red line was 4 lines deep but was ran here.
	                }
	                line = input.readLine();
	            }while (line != null);
	        }catch (FileNotFoundException ex)
	        {
	            System.err.println("I'm sorry. Your file couldn't be found.");
	        }catch (IOException ex)
	        {
	            System.err.println("something I didn't expect went wrong.");
	        }
	        System.out.println("books that were read in: " + booksRead);
	        System.out.println();
	        temp.sort(byYear); //using arraylist to sort before sending the list back. it's using our compareTo to sort on
	        return temp;
	    }
	    
	    public List<Book> getYearSorted(List<Book> old)
	    {
	        List<Book> sorted = old;
	        old.sort(byYear);
	        sorted = old;
	        return sorted;
	    }
	    public List<Book> getAuthorSorted(List<Book> old)
	    {
	        old.sort(byAuthor);
	        List<Book> sorted = old;
	        return sorted;
	    }

	    @Override
	    public int compareTo(Book o)
	    {
	        return this.title.compareTo(o.getTitle());
	    }


	    

	    private static class AuthorComparator implements Comparator<Book>
	    {
	        @Override
	        public int compare(Book o1, Book o2)
	        {
	            String name1 = o1.getAuthor();
	            String name2 = o2.getAuthor();
	            
	            return name1.compareTo(name2);
	        }
	    }

	    
	        
	    
	    private static class YearComparator implements Comparator<Book>
	    {
	        @Override
	        public int compare(Book o1,Book o2)
	        {
	            return (o1.getYear() - o2.getYear());
	        }

	    }
	}




