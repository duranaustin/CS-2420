package books;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

public class BookApp {

	public static void main(String[] args) {
		//File filePath is used for the compareTo method in the book class; Creating File object that reads books.csv
		File filePath = new File("C:\\\\Users\\\\aduran\\\\eclipse-workspace\\\\A00 Books\\\\src\\\\books\\\\books.csv");
		//String file is used for the getList method in the Book Class
		String file = "C:\\Users\\aduran\\eclipse-workspace\\A00 Books\\src\\books\\books.csv";
		//Creating an Array List called bookList to get the length, then converting to an array
		ArrayList<String> bookList = new ArrayList<String>();
		//Call to Scanner method bookScanner with arguments file, and bookList -- creating an updated ArrayList
		bookList = bookScanner(filePath, bookList);
		//bookList is now an array with all lines of Book.csv -- creating myArray
		String[] toolArray = bookList.toArray(new String[0]);
		//Creating an arrayList for each attribute from Title, Author, and Year
		String[] titles = new String[bookList.size()];
		String[] authors = new String[bookList.size()];
		String[] tempYears = new String[bookList.size()];
		Integer[] years = new Integer[bookList.size()];
		//Now we need to substring the title, author, and year into the constructor, to create a book object
		int listLength = toolArray.length; 
		//Creating a book object that will later have arguments that fit its constructor
		Book book[] = new Book[listLength];
		//Creating Array of Lists
		for (int i = 0; i < listLength; i++) {
			titles[i] = subStringTitleTest(toolArray[i]);
			authors[i] = subStringAuthorTest(toolArray[i]);
			tempYears[i] = subStringYearTest(toolArray[i]);	
			}
		//Takes care of authors array to ensure no exception is thrown
		for(int u = 0; u < listLength; u++) 
		{
			try {
			if(authors[u] == null) 
			{
				authors[u] = "";
			}
			else {
			authors[u] = subStringAuthorTest(toolArray[u]);
			}
			}
			catch(NumberFormatException ex) 
			{
			}
		}
		
		//Takes care of tempYears to ensure an exception is not thrown
		for(int j = 0; j < listLength; j++) 
		{
			try {
			if(tempYears[j] == null) 
			{
				years[j] = 0;
			}
			
			else {
			years[j] = Integer.parseInt(tempYears[j]);
			}
			}			
			catch(NullPointerException e) 
			{
			years[j] = 0;
			}
			catch(NumberFormatException e) 
			{
			years[j] = 0;
			}
		}
		//Looping through each index k and creating a new Book object with the
		//Respective arrays titles[], authors[], and years[]
		for(int k = 0; k < listLength; k++) 
		{
			book[k] = new Book(titles[k],authors[k], years[k]);
		}
		
		//Calling getList method to return sorted list.
		book[0].getList(file);
		System.out.println("");
		System.out.println("Reverse Order:");
		
		//Printing booklist in reverse order
		Arrays.sort(book, Collections.reverseOrder());
		for (int i = 0; i < book.length; i++) 
		{
			System.out.println(book[i].toString());		
		}

		}
	
	
	
	/**
	 * subStringTitleTest grabs the elements at index 0 and returns the title
	 */
	private static String subStringTitleTest(String title) {
		try {
		String[] results = title.split(",");
		return results[0];
		} catch (Exception e) {
			}
		return null;
		}
		
	/**
	 * subStringAuthorTest grabs the elements at index 1 and returns the title
	 */
	private static String subStringAuthorTest(String author) {
		try {
		String[] results = author.split(",");
		return results[1];
		} catch (Exception e) {
			}
		return null;
		}
	
	/**
	 * subStringYearTest grabs the elements at index 2 and returns the title
	 */
	private static String subStringYearTest(String year) {
		try {
		String[] results = year.split(",");
		return results[2];
		} catch (Exception e) {
			}
		return null;
		}	

	/**
	 * bookScanner takes a file(book.csv) and returns a String, line by line
	 */
	private static ArrayList bookScanner(File file, ArrayList list) {
		//Creating Scanner object to scan the books.csv file
		Scanner sc;
		try 
		{
			sc = new Scanner(file);
			//Creating String bookLine to store each line of books.csv
			String bookLine = "";
			//While the book still has lines to read from, return each line as a String bookLine
			while (sc.hasNextLine()) 
			{
				bookLine = sc.nextLine();
				list.add(bookLine);
			}
			sc.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return list;
		
	}

}
	