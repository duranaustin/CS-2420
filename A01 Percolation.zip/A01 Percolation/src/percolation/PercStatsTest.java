package percolation;

public class PercStatsTest {

	public static void main(String[] args) {
		PercolationStats perc = new PercolationStats(200, 100);

	}

}
