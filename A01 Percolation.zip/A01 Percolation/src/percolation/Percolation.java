package percolation;

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

/**
 * 
 * @author Austin Duran and Joe Dimmick
 *
 */
public class Percolation {
	// 2D boolean array grid
	private boolean grid[][];
	// virtual top for top row to point to
	private int top;
	// virtual bottom for bottom boxes to point to
	private int bot;
	// size keeps track of size that's getting passed around
	private int size;
	// wUF will be used in the union and connected methods
	WeightedQuickUnionUF wUF;

	/**
	 * Percolation constructor assigns pertinent values attributed to percolation
	 * function. Create N�by�N grid, with all sites blocked
	 */
	public Percolation(int N) {
		// N must be greater than 0, otherwise we're throwing an
		// IllegalArgumentException
		if (N <= 0) {
			throw new IllegalArgumentException("Percolation argument must be greater than 0");
		}
		// row equal to N
		int row = N;
		// column equal to N
		int column = N;
		// grid initialized to i and j for later use-- if i and j equaled 5,5 this would
		// range from 0,0 to 4,4
		grid = new boolean[row][column];
		// wUF is initialized to the grid size + 2 for top and bottom pointer-- if n
		// equaled 5, this would pass
		// 5 * 5 + 2 which would equal 27
		wUF = new WeightedQuickUnionUF(N * N + 2);
		// top ID is equal to n * n which would be 25, if n = 5
		top = N * N;
		// bottom is equal to n * n + 1 which would be 26, if n = 5
		bot = N * N + 1;
		// size = n which would be 5 if n = 5
		size = N;

	}

	/**
	 * Opens site (row i, column j) if it is not open already.
	 */
	public void open(int row, int column) {
		// send i and j to the private method val for validation of range.
		validateRowColumn(row, column);
		int p = twoDimensionaltoOneDimensionalInt(row, column);
		// if row is equal to 0, union the p id to top
		if (row == 0) {
			wUF.union(top, p);
		}
		// if row is equal to size, union the p id to bottom
		if (row == size - 1) {
			// currently causes backwash
			wUF.union(bot, p);
		}

		if (grid[row][column] != true) {
			grid[row][column] = true;
			checkAdj(row, column);
		}
	}

	/**
	 * Returns True if site [i][j] is open.
	 */
	public boolean isOpen(int row, int column) {
		// send i and j to the private method val for validation of range.
		validateRowColumn(row, column);
		if (grid[row][column] == true) {
			return true;
		}
		return false;
	}

	/**
	 * isFull checks to see if our ID has a path way to our top pointer
	 */
	public boolean isFull(int row, int column) {
		// send i and j to the private method val for validation of range.
		validateRowColumn(row, column);
		if (isOpen(row, column) == true) { // first check if open
			return wUF.connected(twoDimensionaltoOneDimensionalInt(row, column), top);
		}
		return false;
	}

	/**
	 * percolates checks to see if top and bot pointers have a pathway to each other
	 */
	public boolean percolates() {
		if (wUF.connected(top, bot)) {
			return true;
		} else
			return false;
	}

	/**
	 * checkAdj checks to see if any sites are open surrounding the i,j id which is
	 * represented by p
	 */
	private void checkAdj(int row, int column) {
		// int p will equal the i and j site that is sent to
		// twoDimensionaltoOneDimensionalInt method
		int p = twoDimensionaltoOneDimensionalInt(row, column);
		// check site above.
		if (column != 0 && grid[row][column - 1]) {
			wUF.union(p, twoDimensionaltoOneDimensionalInt(row, column - 1));
		}
		// check site to the right.
		if (row != (size - 1) && grid[row + 1][column]) {
			wUF.union(p, twoDimensionaltoOneDimensionalInt(row + 1, column));
		}
		// check site below.
		if (column != (size - 1) && grid[row][column + 1]) {
			wUF.union(p, twoDimensionaltoOneDimensionalInt(row, column + 1));
		}
		// check site to the left.
		if (row != 0 && grid[row - 1][column]) {
			wUF.union(p, twoDimensionaltoOneDimensionalInt(row - 1, column));
		}
	}

	/**
	 * getIndex turns our 2D array into a 1D integer if n were to equal 5, we would
	 * have 1D integers ranging from 0-24 if i were to equal 0 and j were to equal
	 * 1, we would return 1 if i were to equal 4 and j were to equal 4, we would
	 * return 24
	 *
	 */
	private int twoDimensionaltoOneDimensionalInt(int row, int column) {
		return size * row + column;
	}

	/**
	 * Validates i and j being within range, otherwise throws an
	 * IndexOutOfBoundsException
	 */
	private void validateRowColumn(int row, int column) {
		if (row < 0 || row >= size)
			throw new IndexOutOfBoundsException("row index " + row + " must be between 0 and " + (size - 1));
		if (column < 0 || column >= size)
			throw new IndexOutOfBoundsException("row index " + column + " must be between 0 and " + (size - 1));
	}

}