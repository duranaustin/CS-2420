package percolation;

import edu.princeton.cs.algs4.StdStats;
import edu.princeton.cs.algs4.StdRandom;


/**
 * 
 * @author Austin Duran and Joe Dimmick
 *
 */
public class PercolationStats {
	private int trials;
	private double[] rate;
	private Percolation perc;
	private int count;
	private int gridSize;

	/**
	 * perform T independent experiments on an NbyN grid
	 */
	public PercolationStats(int N, int T) {
		if (N <= 0 || T <= 0) {
			throw new IllegalArgumentException("Percolation argument must be greater than 0");
		}
		trials = T;
		rate = new double[T];
		count = 0;
		gridSize = N;
		// run() computes our ratios for experiments and plugs them into an array
		run();
	}

	/**
	 * sample mean of percolation threshold does d represent the number of boxes
	 * open?
	 */
	public double mean() {
		return StdStats.mean(rate);
	}

	/**
	 * sample standard deviation of percolation threshold
	 */
	public double stddev() {
		return StdStats.stddev(rate);
	}

	/**
	 * low endpoint of 95% confidence interval x - 1.96 o/sqrt(n)
	 */
	public double confidenceLow() {
		return (mean() - ((1.96 * stddev()) / Math.sqrt(trials)));
	}

	/**
	 * high endpoint of 95% confidence interval x + 1.96 o/sqrt(n)
	 */
	public double confidenceHigh() {
		return (mean() + ((1.96 * stddev()) / Math.sqrt(trials)));
	}

	/**
	 * run() is used to formulate our array of ratios determining when a grid of
	 * size n will percolate
	 */
	private void run() {
		// going to run a set number of percolation trials (T)
		for (int i = 0; i < trials; i++) {
			count = 0;
			perc = new Percolation(gridSize);
			// on a system of N-by-N until it percolates
			while (!perc.percolates()) {
				int rn1 = StdRandom.uniform(gridSize);
				int rn2 = StdRandom.uniform(gridSize);
				// check that throws out duplicate grid points to be opened
				if (perc.isOpen(rn1, rn2) != true) {
					perc.open(rn1, rn2);
					count++;
				}
			}
			// record the success rate of success of each trial in a double
			rate[i] = ((double) count) / (gridSize * gridSize);
		}
//		printStats();
	}

	/**
	 * printStats prints out Stats for Mean, Stddev, CH, and CL
	 */
	private void printStats() {
		System.out.println("Mean: " + mean());
		System.out.println("Stddev: " + stddev());
		System.out.println("confidenceHigh: " + confidenceHigh());
		System.out.println("confidenceLow: " + confidenceLow());
	}

}