package rand_que_deque;

public class RandomizedQueue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
