package puzzle;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.Queue;
import java.util.Arrays;

public class Board {

	private int[][] blocks;
	private int[][] blocksSol;
	private int[] blockArray;
	private int block;
	private int N;
	private Object board;

	/**
	 * construct a board from an N-by-N array of blocks (where blocks[i][j] = block
	 * in row i, column j)
	 */
	public Board(int[][] fromblockArray) {

		// this.blocks = blocks;
		this.N = fromblockArray.length;
		blocks = new int[N][N];

		// Constructing a board from an N-by-N array of blocks
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				this.blocks[i][j] = fromblockArray[i][j];
			}
		}
		int c2d = 1;
		blocksSol = new int[N][N];
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				blocksSol[i][j] = c2d++;
			}
		}
		blocksSol[N - 1][N - 1] = 0;

		// Turning 2d array into 1d array of blocks
		this.blockArray = new int[this.size()];
		// for(int m = 0; m < 1; m++)
		int c = 0;
		for (int k = 0; k < N; k++) {
			for (int l = 0; l < N; l++) {
				this.blockArray[c] = this.blocks[k][l];
				c++;
			}
		}

	}

	/**
	 * board size N
	 */
	public int size() {

		return this.N * this.N;

	}

	/**
	 * number of blocks out of place
	 */
	public int hamming() {
		int c = 0;
		for (int k = 0; k < N; k++) {
			for (int l = 0; l < N; l++) {
				this.blockArray[c] = this.blocks[k][l];
				c++;
			}
		}
		int counter = 0;
		for (int i = 0; i < this.size(); i++) {
			if ((blockArray[i] != i + 1 && blockArray[i] != 0)) {
				counter++;
			}
		}
		return counter;
	}

	/**
	 * sum of Manhattan distances between blocks and goal
	 */
	public int manhattan() {
		int counter;
		int hatten = 0;
		int newRow = 0;
		int newColumn = 0;
		for (int i = 0, j = 0; i < N; j++) {
			if (blocks[i][j] != blocksSol[i][j] && blocksSol[i][j] != 0) {
				counter = blocksSol[i][j];
				for (int z = 0, x = 0; z < N; x++) {
					if (blocks[z][x] == counter) {
						newRow = z;
						newColumn = x;
					}
					if (x == N - 1) {
						x = -1;
						z++;
					}
				}
				while ((newRow != i || newColumn != j)) {
					if (newRow > i) {
						hatten++;
						newRow--;
					} else if (newRow < i) {
						hatten++;
						newRow++;
					}
					if (newColumn < j) {
						hatten++;
						newColumn++;
					} else if (newColumn > j) {
						hatten++;
						newColumn--;
					}
				}
			}
			if (j == N - 1) {
				j = -1;
				i++;
			}
		}
		return hatten;
	}

	/**
	 * is this board the goal board?
	 */
	public boolean isGoal() {
		return (this.hamming() == 0);
	}

	/**
	 * is this board solvable?
	 */
	public boolean isSolvable() {
		int inversions = 0;
		int champion = blockArray.length - 1;
		int blankRow = 0;

		for (int i = blockArray.length - 1; i >= 0; i--) {
			for (int k = i; k >= 0; k--) {
				if (blockArray[k] > blockArray[i] && blockArray[i] != 0) {
					inversions++;
				}
			}

		}
		champion--;

		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				if (blocks[i][j] == 0) {
					blankRow = i;
					break;
				}
			}
		}

		if ((N % 2 != 0) && (inversions % 2 != 0)) {
			return false;
		}
		if ((N % 2 == 0) && (((inversions + blankRow) % 2) == 0)) {
			return false;
		}
		return true;
	}

	/**
	 * does this board equal y?
	 */
	public boolean equals(Object y) {
		if (y == this) {
			return true;
		}
		if (y == null) {
			return false;
		}
		if (y.getClass() != this.getClass()) {
			return false;
		}

		Board that = (Board) y;
		if (this.N != that.N) {
			return false;
		}
		if (!(Arrays.equals(this.blockArray, that.blockArray))) {
			return false;
		}
		if (!(Arrays.deepEquals(this.blocks, that.blocks))) {
			return false;
		}
		return true;
	}

	/**
	 * all neighboring boards
	 */
	public Iterable<Board> neighbors() {
		int row = 0;
		int column = 0;
		int tempcolumnl;
		int temprowt;
		int tempcolumnr;
		int temprowb;
		Queue<Board> temppq = new Queue<Board>();

		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				if (blocks[i][j] == 0) {
					row = i;
					column = j;
				}

			}
		}

		if ((column == 0 || column == N - 1) && (row == 0 || row == N - 1)) {
			Board copy = new Board(blocks);
			Board neighbors2r = new Board(copy.blocks);
			Board neighbors2c = new Board(copy.blocks);
			int tempcolumn = 0;
			int temprow = 0;
			if (column == 0) {
				tempcolumn = column + 1;
			}
			if (column == N - 1) {
				tempcolumn = column - 1;
			}
			if (row == 0) {
				temprow = row + 1;
			}
			if (row == N - 1) {
				temprow = row - 1;
			}
			int r = this.blocks[temprow][column];
			int c = this.blocks[row][tempcolumn];
			neighbors2r.blocks[row][column] = r;
			neighbors2c.blocks[row][column] = c;
			neighbors2r.blocks[temprow][column] = 0;
			neighbors2c.blocks[row][tempcolumn] = 0;
			temppq.enqueue(neighbors2r);
			temppq.enqueue(neighbors2c);
		} else if (((column == 0 || column == N - 1) && (!(row == N - 1 || row == 0)))
				|| ((!(column == N - 1 || column == 0)) && (row == 0 || row == N - 1))) {
			Board neighbors3lt = new Board(blocks);
			Board neighbors3rb = new Board(blocks);
			Board neighbors3mid = new Board(this.blocks);
			int lt;
			int rb;
			int mid;
			if (row == 0 || row == N - 1) {
				tempcolumnl = column - 1;
				tempcolumnr = column + 1;
				lt = this.blocks[row][tempcolumnl];
				rb = this.blocks[row][tempcolumnr];
				if (row == 0) {
					temprowb = row + 1;
					mid = this.blocks[temprowb][column];
					neighbors3lt.blocks[row][column] = lt;
					neighbors3rb.blocks[row][column] = rb;
					neighbors3mid.blocks[row][column] = mid;
					neighbors3lt.blocks[row][tempcolumnl] = 0;
					neighbors3rb.blocks[row][tempcolumnr] = 0;
					neighbors3mid.blocks[temprowb][column] = 0;
				} else {
					temprowt = row - 1;
					mid = this.blocks[temprowt][column];
					neighbors3lt.blocks[row][column] = lt;
					neighbors3rb.blocks[row][column] = rb;
					neighbors3mid.blocks[row][column] = mid;
					neighbors3lt.blocks[row][tempcolumnl] = 0;
					neighbors3rb.blocks[row][tempcolumnr] = 0;
					neighbors3mid.blocks[temprowt][column] = 0;
				}
			} else {
				temprowt = row - 1;
				temprowb = row + 1;
				lt = this.blocks[temprowt][column];
				rb = this.blocks[temprowb][column];
				if (column == 0) {
					tempcolumnr = column + 1;
					mid = this.blocks[row][tempcolumnr];
					neighbors3lt.blocks[row][column] = lt;
					neighbors3rb.blocks[row][column] = rb;
					neighbors3mid.blocks[row][column] = mid;
					neighbors3lt.blocks[temprowt][column] = 0;
					neighbors3rb.blocks[temprowb][column] = 0;
					neighbors3mid.blocks[row][tempcolumnr] = 0;
				} else {
					tempcolumnl = column - 1;
					mid = this.blocks[row][tempcolumnl];
					neighbors3lt.blocks[row][column] = lt;
					neighbors3rb.blocks[row][column] = rb;
					neighbors3mid.blocks[row][column] = mid;
					neighbors3lt.blocks[temprowt][column] = 0;
					neighbors3rb.blocks[temprowb][column] = 0;
					neighbors3mid.blocks[row][tempcolumnl] = 0;

				}

			}
			temppq.enqueue(neighbors3lt);
			temppq.enqueue(neighbors3rb);
			temppq.enqueue(neighbors3mid);
		} else {
			Board neighbors4l = new Board(blocks);
			Board neighbors4r = new Board(this.blocks);
			Board neighbors4t = new Board(this.blocks);
			Board neighbors4b = new Board(this.blocks);
			temprowt = row - 1;
			temprowb = row + 1;
			tempcolumnl = column - 1;
			tempcolumnr = column + 1;
			int t = this.blocks[temprowt][column];
			int l = this.blocks[row][tempcolumnl];
			int b = this.blocks[temprowb][column];
			int r = this.blocks[row][tempcolumnr];
			neighbors4t.blocks[row][column] = t;
			neighbors4b.blocks[row][column] = b;
			neighbors4l.blocks[row][column] = l;
			neighbors4r.blocks[row][column] = r;
			neighbors4t.blocks[temprowt][column] = 0;
			neighbors4b.blocks[temprowb][column] = 0;
			neighbors4l.blocks[row][tempcolumnl] = 0;
			neighbors4r.blocks[row][tempcolumnr] = 0;
			temppq.enqueue(neighbors4t);
			temppq.enqueue(neighbors4b);
			temppq.enqueue(neighbors4l);
			temppq.enqueue(neighbors4r);
		}

		return temppq;
	}

	/**
	 * string representation of this board (in the output format specified below)
	 */
	public String toString() {
		StringBuilder s = new StringBuilder();
		s.append(N + "\n");
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				s.append(String.format("%2d ", this.blocks[i][j]));
			}
			s.append("\n");
		}
		return s.toString();
	}

	public static void main(String[] args) {

		// create initial board from file
		In in = new In("puzzle50.txt");
		int N = in.readInt();
		int[][] blocks = new int[N][N];
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				blocks[i][j] = in.readInt();
			}
		}
		Board initial = new Board(blocks);
		String s = initial.toString();
		System.out.println(s);
		System.out.println(initial.isSolvable());
	}

}