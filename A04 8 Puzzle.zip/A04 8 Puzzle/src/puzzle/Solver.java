package puzzle;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.Stack;

public class Solver {

	private Board board;
	private int move;
	private MinPQ<searchNode> pq = new MinPQ<searchNode>();
	private searchNode first;
	private searchNode last;

	/**
	 * find a solution to the initial board (using the A* algorithm)
	 */
	public Solver(Board temp) {
		if (temp == null) {
			throw new NullPointerException();
		}
		if (temp.isSolvable() == false) {
			throw new IllegalArgumentException();
		}
		this.board = temp;
		first = new searchNode(board);
		pq.insert(first);
		while (!(pq.min().currentboard.isGoal())) {
			searchNode min = pq.min();
			for (Board b : min.currentboard.neighbors()) {
				searchNode tempNode = new searchNode(b, pq.min());
				if (min.previous == null) {
					pq.insert(tempNode);
				} else if (!(tempNode.currentboard.equals(min.previous.currentboard))) {
					pq.insert(tempNode);
				}
			}
			pq.delMin();
		}
		last = pq.delMin();

	}

	/**
	 * Search node class for solutions
	 *
	 */
	private class searchNode implements Comparable {

		private searchNode previous;
		private int hamming;
		private int manhatten;
		private int currentmoves;
		private int priority;
		private Board currentboard;

		public searchNode(Board b) {
			currentboard = b;
			manhatten = currentboard.manhattan();
			hamming = currentboard.hamming();
			previous = null;
			currentmoves = (this.previous != null ? previous.currentmoves + 1 : 0);
			priority = manhatten + currentmoves;

		}

		public searchNode(Board b, searchNode p) {
			currentboard = b;
			manhatten = currentboard.manhattan();
			hamming = currentboard.hamming();
			previous = p;
			currentmoves = (this.previous != null ? previous.currentmoves + 1 : 0);
			priority = manhatten + currentmoves;
		}

		@Override
		public int compareTo(Object o) {

			searchNode test = (searchNode) o;
			return this.priority - test.priority;
		}

	}

	/**
	 * min number of moves to solve initial board
	 */
	public int moves() {

		return last.currentmoves;

	}

	/**
	 * sequence of boards in a shortest solution
	 */
	public Iterable<Board> solution() {
		Stack<Board> finalstack = new Stack<Board>();
		if (last.equals(first)) {
			finalstack.push(first.currentboard);
		} else {
			do {
				finalstack.push(last.currentboard);
				last = last.previous;
			} while (last.previous != null);
			finalstack.push(last.currentboard);
		}
		return finalstack;
	}

	/**
	 * solve a slider puzzle
	 */
	public static void main(String[] args) {
		// create initial board from file
		In in = new In("puzzle09.txt");
		int N = in.readInt();
		int[][] blocks = new int[N][N];
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				blocks[i][j] = in.readInt();
			}
		}
		Board initial = new Board(blocks);

		// check if puzzle is solvable; if so, solve it and output solution
		if (initial.isSolvable()) {
			Solver solver = new Solver(initial);
			StdOut.println("Minimum number of moves = " + solver.moves());
			for (Board board : solver.solution()) {
				StdOut.println(board);
			}

		} // if not, report unsolvable
		else {
			StdOut.println("Unsolvable puzzle");
		}
	}

}