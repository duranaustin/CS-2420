package puzzle;

import edu.princeton.cs.algs4.In;

public class TestClient {

	public static void main(String[] args) {

	    // create initial board from file
	    In in = new In("C:\\Users\\aduran\\Downloads\\puzzletest.txt");
	    int N = in.readInt();
	    int[][] blocks = new int[N][N];
	    for (int i = 0; i < N; i++)
	        for (int j = 0; j < N; j++)
	            blocks[i][j] = in.readInt();
	    Board initial = new Board(blocks);

	    String s = initial.toString();
	    System.out.println(s);
//	    // check if puzzle is solvable; if so, solve it and output solution
//	    if (initial.isSolvable()) {
//	        Solver solver = new Solver(initial);
//	        StdOut.println("Minimum number of moves = " + solver.moves());
//	        for (Board board : solver.solution())
//	            StdOut.println(board);
//	    }
//
//	    // if not, report unsolvable
//	    else {
//	        StdOut.println("Unsolvable puzzle");
//	    }
	}

}
