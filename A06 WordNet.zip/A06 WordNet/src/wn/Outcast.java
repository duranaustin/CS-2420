package wn;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

/**
 * 
 * @author Kyle Fackrell & Austin Duran
 *
 */
public class Outcast {
	
	private WordNet wn;

	// constructor takes a WordNet object
	public Outcast(WordNet wordnet) {
		this.wn = wordnet;
	}

	// given an array of WordNet nouns, return an outcast
	public String outcast(String[] nouns) {
		String outcast = null;
		int maxDistance = 0;
		
		for (int i = 0; i < nouns.length; i++) {
			int distance = 0;
			for (int j = 0; j < nouns.length; j++) {
				if (!nouns[i].equals(nouns[j])) {
					distance += wn.distance(nouns[i], nouns[j]);
				}
				
			}
			if (distance > maxDistance) {
				maxDistance = distance;
				outcast = nouns[i];
			}
		}
		return outcast;
	}

	// see test client below
	public static void main(String[] args) {
		String s = "synsets.txt";
		String h = "hypernyms.txt";
	    WordNet wordnet = new WordNet(s, h);
	    Outcast outcast = new Outcast(wordnet);
//	    for(outcast.outcast(nouns))
//	    for (int t = 2; t < s.length; t++) {
//	        In in = new In(args[t]);
//	        String[] nouns = in.readAllStrings();
//	        StdOut.println(args[t] + ": " + outcast.outcast(nouns));
//	    }
	}

}
