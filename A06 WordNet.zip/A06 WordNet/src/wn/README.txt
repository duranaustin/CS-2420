/******************************************************************************
 *  Name: Austin Duran 
 *  NetID:    
 *  Precept:  
 *
 *  Partner Name: Kyle Fackrell    
 *  Partner NetID:    
 *  Partner Precept:  
 *
 *  Hours to complete assignment (optional):
 *
 ******************************************************************************/

Programming Assignment 6: WordNet


/******************************************************************************
 *  Describe concisely the data structure(s) you used to store the 
 *  information in synsets.txt. Why did you make this choice?
 *****************************************************************************/
 We stored synsets.txt using 2 Symbol Tables that 1. "NounKeyST" that had each Noun as the Key of the 
 Symbol table with the respective ID(s) as its values. (String)(Integer) iterable if needed, symbol table. 
 2. "IdKeyST" that had each ID as the Key of the Symbol table with the respective noun(s) as its values. 
 (Integer)(String) iterable if needed, symbol table.
 
 We made this choice since we knew that we would want reference to an ID or a Noun for our
 SAP class implementation. A Symbol table was flexible and easy to work with. 


/******************************************************************************
 *  Describe concisely the data structure(s) you used to store the 
 *  information in hypernyms.txt. Why did you make this choice?
 *****************************************************************************/
 We stored hypernyms.txt into a Digraph after we had all the useful Symbol Table data structures from Synsets.txt.
 We made this choice - simply because we were kind of told to in the step by step instructions. 
 A digraph with respective vertices and edges just made sense. 


/******************************************************************************
 *  Describe concisely the algorithm you use in the constructor of
 *  ShortestCommonAncestor to check if the digraph is a rooted DAG.
 *  What is the order of growth of the worst-case running times of
 *  your algorithms as a function of the number of vertices V and the
 *  number of edges E in the digraph?
 *****************************************************************************/

Description: We first check to make sure that the digraph is a DAG and return
false if isDAG is false. We keep track of the number of roots with int roots
and we loop through all the vertices. If a vertex has an empty adjacency
list we increment roots by 1. We return true only if we end with roots
equal to 1.



Order of growth of running time: - E + V


/******************************************************************************
 *  Describe concisely your algorithm to compute the shortest common
 *  ancestor in ShortestCommonAncestor. For each method, what is the order of
 *  growth of the worst-case running time as a function of the number of
 *  vertices V and the number of edges E in the digraph? For each method,
 *  what is the order of growth of the best-case running time?
 *
 *  If you use hashing, you should assume the uniform hashing assumption
 *  so that put() and get() take constant time.
 *
 *  Be careful! If you use a BreadthFirstDirectedPaths object, don't
 *  forget to count the time needed to initialize the marked[],
 *  edgeTo[], and distTo[] arrays.
 *****************************************************************************/

Description: A BreadthFirstDirectedPaths object is created for the v and w
vertices. We find an ancestor by looping through the vertices until both the
vertices have a path to the vertex i that we are checking. We then find the
distance from v to i and w to i, add them together, and store the total into
distance. For the first run, we store the distance into minLength and the
vertex i as the ancestor. If we find another ancestor with a smaller distance,
we store it as the new minLength and ancestor (shortest ancesteral path). We
do this until we loop through all the vertices and return the minLength for
length or the ancestor for ancestor.

                                              running time
method                               best case            worst case
------------------------------------------------------------------------
length(int v, int w)				E + V					E + V

ancestor(int v, int w)				E + V					E + V

length(Iterable<Integer> v,			E + V					E + V
       Iterable<Integer> w)

ancestor(Iterable<Integer> v,		E + V					E + V
         Iterable<Integer> w)




/******************************************************************************
 *  Known bugs / limitations.
 *****************************************************************************/
-

/******************************************************************************
 *  Describe whatever help (if any) that you received.
 *  Don't include readings, lectures, and precepts, but do
 *  include any help from people (including course staff, lab TAs,
 *  classmates, and friends) and attribute them by name.
 *****************************************************************************/
-

/******************************************************************************
 *  Describe any serious problems you encountered.                    
 *****************************************************************************/

-
/******************************************************************************
 *  If you worked with a partner, assert below that you followed
 *  the protocol as described on the assignment page. Give one
 *  sentence explaining what each of you contributed.
 *****************************************************************************/
 Austin Duran implemented most of the WordNet class. 
 Kyle Fackrell implemented most of the SAP and OutCast classes.


/**********************************************************************
 *  Have you completed the mid-semester survey? If you haven't yet,
 *  please complete the brief mid-course survey at https://goo.gl/gB3Gzw
 * 
 ***********************************************************************/


/******************************************************************************
 *  List any other comments here. Feel free to provide any feedback   
 *  on how much you learned from doing the assignment, and whether    
 *  you enjoyed doing it.                                             
 *****************************************************************************/