package wn;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import edu.princeton.cs.algs4.BinarySearchST;
import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.ST;

/**
 * 
 * @author Austin Duran & Kyle Fackrell
 *
 */
public class WordNet {

	private ST idKeyST; // Symbol Table Key (ID) Value (Noun)
	private ST nounKeyST; // Symbol Table Key (Noun) Value (ID) - list
	private ArrayList nounsList; // Contains all nouns from input
	private ArrayList idList; // Contains all ids from input
	private BinarySearchST<String, ArrayList<Integer>> nounBinarySearchST; // BinarySearchST version of our nounKeyST
	private final int V; // number of vertices in this digraph
	private int E; // number of edges in this digraph
	private Digraph digraph;
	private SAP sap;

	/**
	 * WordNet constructor takes arguments of two input files Synsets file is a list
	 * of Nouns Hypernyms file is a construction of hypernyms(generic) and
	 * hyponyms(specific) -- and their relation to each other.
	 * 
	 * @param synsets
	 * @param hypernyms
	 */
	public WordNet(String synsets, String hypernyms) {
		if (synsets == null || hypernyms == null) // Check appropriate input files
			throw new NullPointerException();

		idKeyST = idST(synsets);
		nounKeyST = nounsST(synsets);
		nounsList = buildNounList(synsets);
		idList = buildIdList(synsets);
		nounBinarySearchST = buildNounBinarySearchST(synsets);
		V = getSize();
		digraph = buildDigraph(hypernyms);
		E = digraph.E();
		sap = new SAP(digraph);


		if (this.isDag() == false) 									
			throw new IllegalArgumentException(); 
													

	}
	
	/**
	 * Object to represent a hypernym row in the Hypernyms list
	 * 
	 * @author ADuran
	 *
	 */
	private class Hypernym {
		public Integer idHypernym;
		public List<Integer> idHyponyms;
	}

	/**
	 * parseHypernym splits each row in the Hypernym list and initializes the idHypernym and idHyponym of each row
	 *
	 * @param row
	 * @return
	 */
	private Hypernym parseHypernym(String row) {
		String[] vals = row.split(",");
		Hypernym h = new Hypernym();
		h.idHypernym = Integer.parseInt(vals[0]);
		ArrayList<Integer> idHyponyms = new ArrayList<Integer>();
		for(int j = 1; j < vals.length; j++) 
		{
			idHyponyms.add(Integer.parseInt(vals[j]));
		}
		h.idHyponyms = idHyponyms;

		return h;
	}

	/**
	 * Builds digraph using hypernyms - needs V which we have, needs E which is constructed after the digraph is constructed 
	 * @param hypernyms
	 * @return
	 */
	private Digraph buildDigraph(String hypernyms) {
		In in = new In(hypernyms);
		Digraph tempGraph = new Digraph(this.V);
		
		String s = in.readAll();

		String[] lines = s.split("\\r?\\n");
		for (int i = 0; i < lines.length; i++) {
			Hypernym h = parseHypernym(lines[i]);
			for(int j = 0; j < h.idHyponyms.size(); j++) 
			{
				tempGraph.addEdge(h.idHypernym, h.idHyponyms.get(j)); 
			}
		}
		
		return tempGraph;
	}

	/**
	 * Size of ST 
	 * @return
	 */
	private int getSize() {
		return idKeyST.size();
	}

	/**
	 * Object to represent a row in the Synsets list
	 * 
	 * @author ADuran
	 *
	 */
	private class Row {
		public Integer id;
		public List<String> nouns;
		public String description;
	}

	/**
	 * parseRow splits each row in the Sysnsets list and initialized the id, nouns,
	 * and desription of each row
	 * 
	 * @param row
	 * @return
	 */
	private Row parseRow(String row) {
		String[] vals = row.split(",");
		Row r = new Row();
		r.id = Integer.parseInt(vals[0]);
		r.nouns = Arrays.asList(vals[1].split(" "));
		r.description = vals[2]; // Unused - maybe for testing

		return r;
	}

	/**
	 * ID Symbol table initializer - Key (ID) Value (Nouns)
	 * 
	 * @param synsets
	 * @return
	 */
	private ST idST(String synsets) {
		ST<Integer, List<String>> tempST = new <Integer, List<String>>ST(); // Symbols's table tempST - ID as (Key) -
																			// Noun as (Value)

		In in = new In(synsets);
		String s = in.readAll();

		String[] lines = s.split("\\r?\\n");
		for (int i = 0; i < lines.length; i++) {
			Row r = parseRow(lines[i]);
			tempST.put(r.id, r.nouns); // ID's and Noun's added to Symbol's Table
		}
		return tempST;
	}

	/**
	 * ID Symbol table initializer - Key (Noun) Value (ID)
	 * 
	 * @param synsets
	 * @return
	 */
	private ST nounsST(String synsets) {

		In in = new In(synsets);
		String s = in.readAll();

		ST<String, ArrayList<Integer>> tempST = new ST<String, ArrayList<Integer>>();

		String[] lines = s.split("\\r?\\n");

		for (int i = 0; i < lines.length; i++) { // For the length of lines array, work through each substring
			Row r = parseRow(lines[i]);
			for (int j = 0; j < r.nouns.size(); j++) {
				if (tempST.get(r.nouns.get(j)) == null) {
					tempST.put(r.nouns.get(j), new ArrayList<Integer>());
				}
				tempST.get(r.nouns.get(j)).add(r.id);
			}
		}
		return tempST;
	}

	/**
	 * buildNounList uses a Row object to help build the nounsList
	 * 
	 * @param synsets
	 * @return
	 */
	private ArrayList<String> buildNounList(String synsets) {
		In in = new In(synsets);
		String s = in.readAll();

		ArrayList<String> tempList = new ArrayList<String>();

		String[] lines = s.split("\\r?\\n");
		for (int i = 0; i < lines.length; i++) {
			Row r = parseRow(lines[i]);

			tempList.addAll(r.nouns);

		}
		return tempList;
	}

	/**
	 * buildIdList uses a Row object to help build the idList
	 * 
	 * @param synsets
	 * @return
	 */
	private ArrayList<Integer> buildIdList(String synsets) {
		In in = new In(synsets);
		String s = in.readAll();

		ArrayList<Integer> tempList = new ArrayList<Integer>();

		String[] lines = s.split("\\r?\\n");
		for (int i = 0; i < lines.length; i++) {
			Row r = parseRow(lines[i]);

			tempList.add(r.id);

		}
		return tempList;
	}

	/**
	 * Helper method to determine isDag using hypernyms
	 * 
	 * @return
	 */
	private boolean isDag() {
		return sap.isDAG();

	}

	/**
	 * returns all WordNet nouns
	 * 
	 * @return
	 */
	public Iterable<String> nouns() {
		return nounsList;
	}

	/**
	 * returns all WordNet ids
	 * 
	 * @return
	 */
	private Iterable<Integer> ids() {
		return idList;
	}

	/**
	 * is the word a WordNet noun? - Logarithmic
	 * 
	 * @param word
	 * @return
	 */
	public boolean isNoun(String word) {
		if (word == null)
			throw new NullPointerException();
		if (nounBinarySearchST.contains(word)) {
			return true;
		}
		return false;
	}

	/**
	 * buildBinarySearchST uses a Row object to help build the nounsList using a
	 * binarySearchST
	 * 
	 * @param synsets
	 * @return
	 */
	private BinarySearchST<String, ArrayList<Integer>> buildNounBinarySearchST(String synsets) {
		In in = new In(synsets);
		String s = in.readAll();

		BinarySearchST<String, ArrayList<Integer>> tempST = new BinarySearchST<String, ArrayList<Integer>>();

		String[] lines = s.split("\\r?\\n");

		for (int i = 0; i < lines.length; i++) { // For the length of lines array, work through each substring
			Row r = parseRow(lines[i]);
			for (int j = 0; j < r.nouns.size(); j++) {
				if (tempST.get(r.nouns.get(j)) == null) {
					tempST.put(r.nouns.get(j), new ArrayList<Integer>());
				}
				tempST.get(r.nouns.get(j)).add(r.id);
			}
		}
		return tempST;
	}

	/**
	 * distance between nounA and nounB (defined below) 
	 * 
	 * @param nounA
	 * @param nounB
	 * @return
	 */
	public int distance(String nounA, String nounB) {
		if (nounA == null || nounB == null)
			throw new NullPointerException();
		if (this.isNoun(nounA) == false || this.isNoun(nounB) == false) // Check if isNoun
			throw new IllegalArgumentException();
		
		Iterable<Integer> nounIntA = nounBinarySearchST.get(nounA); 
		Iterable<Integer> nounIntB = nounBinarySearchST.get(nounB);
		int distance = sap.length(nounIntA, nounIntB);

		return distance;
	}

//	/**
//	 * Parses the first element of the nounKeyST value upon specific noun
//	 * @param nounA
//	 * @param nounB
//	 * @return 
//	 */
//	private int nounIntegerParser(String noun) {
//		Object a = nounKeyST.get(noun);
//		String nounString = a.toString();
//		ArrayList<Integer> tempArrayList = new ArrayList<Integer>();
//		if(nounString.contains(",")) {
//		String[] lines = nounString.split(",");
//		for(String s: lines) 
//		{
//			tempArrayList.add(Integer.parseInt(s));
//		}
//
//		}
//		else {
//			tempArrayList.add(Integer.parseInt(nounString.substring(1,nounString.length() -1)));
//		}	
//		
//		return tempArrayList;
//	}

	/**
	 * a synset (second field of synsets.txt) that is the common ancestor of nounA
	 * and nounB in a shortest ancestral path (defined below) 
	 * 
	 * @param nounA
	 * @param nounB
	 * @return
	 */
	public String sap(String nounA, String nounB) {
		if (nounA == null || nounB == null)
			throw new NullPointerException();
		if (this.isNoun(nounA) == false || this.isNoun(nounB) == false) // Check if isNoun
			throw new IllegalArgumentException();
		
		Object a = nounKeyST.get(nounA);
		String nounStringA = a.toString();
		
		Object b = nounKeyST.get(nounB);
		String nounStringB = b.toString();
		
		ArrayList<Integer> nounIntA = new ArrayList<Integer>();
		ArrayList<Integer> nounIntB = new ArrayList<Integer>();
		
		if(nounStringA.contains(",")) 
		{
			nounIntA = iterableID(nounStringA);
		}
		if(nounStringB.contains(",")) 
		{
			nounIntB = iterableID(nounStringB);
		}
		if(!nounStringA.contains(",")) 
		{
			nounIntA = intID(nounStringA);
		}
		if(!nounStringB.contains(",")) 
		{
			nounIntB = intID(nounStringB);
		}

		int ancestorID;
		ancestorID = sap.ancestor(nounIntA, nounIntB);
		
		Object c = idKeyST.get(ancestorID);
		String idString = c.toString();
		return idString;
	}

	/**
	 * Helper method to add nounString to an Iterable arraylist
	 * @param nounString
	 * @return
	 */
	private ArrayList<Integer> intID(String nounString) {
		ArrayList<Integer> tempArrayList = new ArrayList<Integer>();
		String[] lines = new String[1];
		for(String s: lines) 
		{
			tempArrayList.add(Integer.parseInt(nounString.substring(1,nounString.length() -1)));
		}
		return tempArrayList;
	}

	/**
	 * Helper method to parse all elements that would be in nounString and add it to arrayList
	 * @param nounString
	 * @return
	 */
	private ArrayList<Integer> iterableID(String nounString) {
//		System.out.println(nounString);
		nounString = nounString.substring(1,nounString.length() -1);
		ArrayList<Integer> tempArrayList = new ArrayList<Integer>();
		String[] lines = nounString.split(",");
		for(String s: lines) 
		{
			s = s.replaceAll("\\s","");
//			System.out.println(s);
			tempArrayList.add(Integer.parseInt(s));
		}
		return tempArrayList;
		
	}

	/**
	 * Parses the ancestorID to a string
	 * @param ancestorID
	 * @return
	 */
	private String idStringParser(int ancestorID) {
		Object a = idKeyST.get(ancestorID);
		String nounString = a.toString();
		nounString = nounString.substring(1, nounString.length() -1);
		return nounString;
	}

	// do unit testing of this class
	public static void main(String[] args) {
		String synsets = "C:\\Users\\aduran\\Downloads\\synsets.txt";
		String hypernyms = "C:\\Users\\aduran\\Downloads\\hypernyms.txt";

		WordNet wn = new WordNet(synsets, hypernyms);
//		System.out.println(wn.idKeyST.get(49801));
//		System.out.println(wn.nounKeyST.get("bird"));
//		System.out.println(wn.digraph.toString());
//		System.out.println(wn.isNoun("zygote"));
		System.out.println(wn.distance("bird", "worm"));
		System.out.println(wn.sap("bird", "worm"));
//		for(Object e: wn.idList) 
//		{
//			System.out.println(e);
//		}
//		System.out.println(wn.nouns());

	}

}
