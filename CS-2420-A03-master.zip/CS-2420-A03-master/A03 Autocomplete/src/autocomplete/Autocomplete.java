package autocomplete;

public class Autocomplete {

	/**
	 * Initialize the data structure from the given array of terms.
	 * should make proportional to N log N compares (or better) in the worst case, where N is the number of terms.
	 */
	public Autocomplete(Term[] terms) {
		if (terms == null) 
		{
			throw new NullPointerException("list cannot be empty");
		}
		
	}
	
	/**
	 * Return all terms that start with the given prefix, in descending order of weight.
	 * should make proportional to log N + M log M compares (or better) in the worst case, where M is the number of matching terms.
	 */
	public Term[] allMatches(String prefix) 
	{
		if (prefix == null) 
		{
			throw new NullPointerException("prefix cannot be blank");
		}	
	}
	
	/**
	 * Return the number of terms that start with the given prefix.
	 * should make proportional to log N compares (or better) in the worst case.
	 */
	public int numberOfMatches(String prefix) 
	{
		if (prefix == null) 
		{
			throw new NullPointerException("prefix cannot be blank");
		}	
	}

}
