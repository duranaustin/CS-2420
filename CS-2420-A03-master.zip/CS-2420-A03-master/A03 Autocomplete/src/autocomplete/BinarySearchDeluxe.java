package autocomplete;

import java.util.Comparator;

public class BinarySearchDeluxe {
	
	/**
	 * Return the index of the first key in a[] that equals the search key, or -1 if no such key.
	 * should make at most 1 + [log2 N] compares in the worst case
	 */
	public static <Key> int firstIndexOf(Key[] a, Key key, Comparator<Key> comparator) 
	{
		if (a == null || key == null || comparator == null) 
		{
			throw new NullPointerException();
		}
		return 0;
		
	}
	
	/**
	 * Return the index of the last key in a[] that equals the search key, or -1 if no such key.
	 * should make at most 1 + [log2 N] compares in the worst case
	 */
	public static <Key> int lastIndexOf(Key[] a, Key key, Comparator<Key> comparator) 
	{
		if (a == null || key == null || comparator == null) 
		{
			throw new NullPointerException();
		}
		return 0;
		
	}

}
