package autocomplete;

public class Term implements Comparable<Term> {

	/**
	 * Initialize a term with the given query string and weight.
	 */
	public Term(String query, double weight) 
	{
		if (query == null)
		{
			throw new NullPointerException("query is empty");
		}
		if (weight < 0) 
		{
			throw new IllegalArgumentException("weight must be non-negative");
		}
	}
	
	/**
	 * Compare the terms in descending order by weight.
	 */
	public static Comparator<Term> byReverseWeightOrder()
	{
		
	}
	
	/**
	 * Compare the terms in lexicographic order but using only the first r characters of each query.
	 */
	public static Comparator<Term> byPrefixOrder(int r)
	{
		if (r < 0) 
		{
			throw new IllegalArgumentException("r must be non-negative");
		}
	}
	
	/**
	 * Compare the terms in lexicographic order by query.
	 */
	public int compareTo(Term that) 
	{
		if (that == null) 
		{
			throw new NullPointerException();
		}
		// TODO Auto-generated method stub
		return 0;
	}
	
	/**
	 * Return a string representation of the term in the following format:
	 * the weight, followed by a tab, followed by the query.
	 */
	public String toString() 
	{
		return "";
	}
}
